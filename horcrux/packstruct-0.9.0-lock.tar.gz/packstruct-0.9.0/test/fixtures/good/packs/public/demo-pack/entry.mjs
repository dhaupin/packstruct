export default { checks: [] }
